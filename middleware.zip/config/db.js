// import mongoose from "mongoose";
// import dotenv from "dotenv";

// dotenv.config(); // Load environment variables

// export const connectDB = async () => {
//     try {
//         const dbUri = process.env.DB_URI;
//         await mongoose.connect(dbUri);
//         console.log('MongoDB connected successfully');
//     } catch (error) {
//         console.error('MongoDB connection failed:', error.message);
//         process.exit(1);
//     }
// };
